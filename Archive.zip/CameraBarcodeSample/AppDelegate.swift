

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

	var window: UIWindow?


	func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
		
		/*When the application starts-up, vcdp is created for the purpose of propagating the application object to the initial view controller (VC)
		which will further distribute it to subsequent VCs */
		
		let vcdp = ViewControllerDataPropagation(application: application)
		let nextVC = self.window!.rootViewController as! ViewController
		nextVC.vcdp = vcdp
		
		return true
	}
}

