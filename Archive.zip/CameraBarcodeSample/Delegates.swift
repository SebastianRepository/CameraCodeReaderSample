
import Foundation
import UIKit
import AVFoundation


protocol CameraAndReaderDelegate {

	func application() -> UIApplication	
}

//The CodeReaderVC sends messages to a delegate (usually CodeReaderSupportVC)
protocol CodeReaderViewDelegate: CameraAndReaderDelegate {
	
	func enableCaptureButton()  //The delegate may enable the Capture button
	func disableCaptureButton()  // The delegate needs to disable the Capture button
	func dismissAndHandOver(decodedText decodedText: String?)  /*The code reader has successfully decoded a QR code; the delegate may dismiss itself and hand the decoded textover
		to its presenting VC or to business logic */

}

//The CodeReaderSupportVC sends messages to its delegate (usually CodeReaderVC)
protocol CodeReaderSupportViewDelegate {

	func captureButtonHit() //The delegate is informed that the Capture button was touched by the user; it is up to the delegate to act upon the user input
	func cancelButtonHit()  //The delegate is informed that the Cancel button was touched by the user; it is up to the delegate to act upon the user input
	func setCodeReaderTexts(requiredDecodedText rt: String?, informationText it: String) -> Void /* The CodeReaderVC can be sent a very brief, customized information text
	which will be presented to the user on top of the video stream. If the parameter's value is nil, the default information text will be presented. 
	Furthermore, it can be sent 'requiredDecodedText', which is the text required for the code reader to have decoded after having scanned a QR code so as to send a :enableCaptureButton message to its delegate */
}


//CameraVC communicates with CameraSupportVC if the latter adheres to this delegate
protocol CameraViewDelegate: CameraAndReaderDelegate {
	
	func dismissAndHandOver(picture picture: UIImage?) -> Void  //After having captured a picture, CameraVC advises its delegate to dismiss itself and hand over the picture to its presenting VC or to business logic */
}

//CameraSupportVC provides the camera with information about user inputs and about the physical device's capabilities
protocol CameraSupportViewDelegate {

	var parentVC: CameraViewDelegate? { get set }  //The CameraViewDelegate (usually CameraSupportVC) which embeds CameraView

	func capture() -> Void //User pressed the Capture button
	func cancel() -> Void  //User hit the Cancel button
	func flashMode() -> AVCaptureFlashMode  //Returns the camera's current flash mode
	func setFlashMode(newMode: AVCaptureFlashMode) -> AVCaptureFlashMode? //Change the flash's mode to newMode and return newMode if successful; usually after respective user input
	func torchMode() -> AVCaptureTorchMode  //Change to torch on or off, and return the newly set mode; usually the user first selects the mode and CameraSupportVC informs CameraVC by using this method
	func setTorchMode(newMode: AVCaptureTorchMode) -> AVCaptureTorchMode?  //Returns the camera's current torch mode
	func deviceHasFlash() -> Bool?  //Returns true if the physical device supports flashing
	func deviceHasTorch() -> Bool? //Returns true if the physical device supports torch
	func setInfoText(text: String) -> Void  /* The camera can be sent a very brief, customized information text
	which will be presented to the user on top of the video stream. Otherwise, the default information text will be presented.  */
}

//CameraSupportVC's presenting VC or a business logic class will normally be the CameraPictureReceiver
protocol CameraPictureReceiver {

	//CameraView will provide the new picture through this method
	func newPictureAvailable(picture picture: UIImage) -> Void
}
