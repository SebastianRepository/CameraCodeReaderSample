

import Foundation
import UIKit

//A class containing general purpose methods
class Utilities {

	//Resizes a given image to a new height while keeping its aspect ratio
	class func resizeImage(image: UIImage, newHeight: CGFloat) -> UIImage {
		
		let scale = newHeight / image.size.height
		let newWidth = image.size.width * scale
		
		UIGraphicsBeginImageContext(CGSizeMake(newWidth, newHeight))
		
		image.drawInRect(CGRectMake(0, 0, newWidth, newHeight))
		
		let newImage = UIGraphicsGetImageFromCurrentImageContext()
		
		UIGraphicsEndImageContext()

		return newImage
	}
}

/*This structure can be used to propagate certain objects and variables used application - wide from class to class
Struct was chosen over Class because usually only one instance per app will suffice. */
struct ViewControllerDataPropagation {

	var application: UIApplication
	
	init (application app: UIApplication) {
	
		application = app
	}
}