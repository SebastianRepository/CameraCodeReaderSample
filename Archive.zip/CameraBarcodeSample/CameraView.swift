


import UIKit
import AVFoundation
import ImageIO
 
class CameraViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate, CameraSupportViewDelegate {
 
	private let session = AVCaptureSession()  //Coordinates the data flow between input & output
    private var previewLayer = AVCaptureVideoPreviewLayer()
	private var captureDevice: AVCaptureDevice?
	private let output = AVCaptureStillImageOutput()	/*OUTPUT, JPEG (compression is hardware-accelerated
				=> leave the setting of the compression format to AVFoundation ) */
	private var cameraIsNotAvailable: Bool = false
	private var currentFlashMode: AVCaptureFlashMode = .Auto
	private var currentFocusMode: AVCaptureFocusMode = .ContinuousAutoFocus
	private var currentTorchMode: AVCaptureTorchMode = .Off
	private let defaultExposureMode: AVCaptureExposureMode = .ContinuousAutoExposure
    private var focusBorder: BorderOverlay
    private var borderTimer: NSTimer?
	internal var parentVC: CameraViewDelegate?
    
	@IBOutlet weak var informationLabel: UILabel!
	@IBOutlet var tapGestureRecognizer: UITapGestureRecognizer!
	
    required init?(coder: NSCoder)
    {        
        
        let rect = CGRect()
        self.focusBorder = BorderOverlay(frame: rect)
		
        super.init(coder: coder)
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: NSBundle?) {
       
        
        let rect = CGRect()
        self.focusBorder = BorderOverlay(frame: rect)
		
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
	
	          
    override func viewDidLoad() {
        super.viewDidLoad()
		
		//Configure the SESSION: Preset the quality to medium, suitable for 3G sharing:
		if self.session.canSetSessionPreset(AVCaptureSessionPresetMedium) {
			self.session.sessionPreset = AVCaptureSessionPresetMedium
		} 
		
		//Check whether the camera is available to this app
        if let device = getCaptureDevice() {
			
			self.captureDevice = device
			checkDeviceAuthorizationStatus(self.captureDevice!)
			
		} else {
		
			self.cameraIsNotAvailable = true
		}
		
		//Add an observer that will trigger an update of the preview layer when the subject area changes, e.g. due to manual focusing
		if self.captureDevice != nil {
			let defaultCenter = NSNotificationCenter.defaultCenter()
			defaultCenter.addObserver(self, selector: "subjectAreaDidChange:", name: AVCaptureDeviceSubjectAreaDidChangeNotification, object: self.captureDevice!)
		}
    }
	
	override func viewWillLayoutSubviews() {
		
		let app = (self.parentViewController as! CameraViewDelegate).application()
		switch app.statusBarOrientation {
			case UIInterfaceOrientation.LandscapeLeft: rotateSubviewsToHorizontalLeft()
			case UIInterfaceOrientation.LandscapeRight: rotateSubviewsToHorizontalRight()
			case UIInterfaceOrientation.PortraitUpsideDown: rotateSubviewsToUpsideDown()
			case UIInterfaceOrientation.Portrait: fallthrough
			case UIInterfaceOrientation.Unknown: fallthrough
			default: rotateSubviewsToVertical()
		}
	}
	
	override func viewDidLayoutSubviews() {

		super.viewDidLayoutSubviews()

		//Subview layout finished: The view is loaded, i.e. an alert controller can be displayed to inform the user about missing camera access 
		if self.cameraIsNotAvailable {
			
			dismissDueToCameraNotAvailable()
		}
	}
	
    override func didReceiveMemoryWarning() {
        
        self.stop()
    }
	
	
	override func viewDidDisappear(animated: Bool) {
		super.viewDidDisappear(animated)
		
		if self.captureDevice != nil {
		
			let defaultCenter = NSNotificationCenter.defaultCenter()
			defaultCenter.removeObserver(self, name: AVCaptureDeviceSubjectAreaDidChangeNotification, object: self.captureDevice!)
		}
	}
	

	@IBAction func tapAction(sender: AnyObject) {
	
		if self.captureDevice?.focusPointOfInterestSupported == true{

			//Focus, draw border, start timer:
			let touchLocation = tapGestureRecognizer.locationInView(self.view)
		
			let pointOfInterest = self.previewLayer.captureDevicePointOfInterestForPoint(touchLocation)
			focusWithMode(self.captureDevice!, focusMode: AVCaptureFocusMode.AutoFocus, exposureMode: AVCaptureExposureMode.AutoExpose, monitorSubjectAreaChange: true, focusPoint: pointOfInterest, focusRectCenter: touchLocation)
			
		} 
    }
	
	@objc func subjectAreaDidChange(notification: NSNotification) {
	
		if let device = self.captureDevice {
		
			let defaultPoint = CGPointMake(0.5, 0.5)
			focusWithMode(device, focusMode: AVCaptureFocusMode.ContinuousAutoFocus, exposureMode: AVCaptureExposureMode.ContinuousAutoExposure, monitorSubjectAreaChange: false, focusPoint: defaultPoint, focusRectCenter: nil)
		}
	}
	
	private func dismissDueToCameraNotAvailable() {
		
		self.previewLayer.removeFromSuperlayer()
				
		if self.parentVC != nil {
		
			let VC = self.parentVC as! UIViewController

			let alert = AlertController(
				buttons: .OK, 
				title: "Camera not available", 
				messageText: "Please go to Settings and make the backside camera available for this app", 
				btn1Action: { () -> Void in
					(self.parentViewController as! CameraViewDelegate).dismissAndHandOver(picture: nil)  //ANIMATION MUST BE FALSE; otherwise it may not work due to the appearance-animation of this VC still running
				}, 
				btn2Action: nil)
							
			//The built target is iOS 8 => alert may be force-unwrapped without risk of the app crashing
			alert!.present(parent: VC)
			
		} 
	}
	
	//Returns the capture device (backside camera; video for the preview stream), or nil if not available
	private func getCaptureDevice() -> AVCaptureDevice? {
	
		let devices = AVCaptureDevice.devices()
		var returnValue: AVCaptureDevice?
		
		//Loop through all the capture devices
        for device in devices {
            // Make sure this particular device supports video
            if (device.hasMediaType(AVMediaTypeVideo)) {
                // Finally check the position and confirm we've got the back camera
                if(device.position == AVCaptureDevicePosition.Back) {
				
                    if let foundDevice = device as? AVCaptureDevice {
					
						returnValue = foundDevice
                    }
                }
            }
        }
		
		return returnValue
	}
	
	private func prepareSession() {
	
		var error : NSError?
		
		let inputDevice: AVCaptureDeviceInput!
		
		do {
			inputDevice = try AVCaptureDeviceInput(device: captureDevice)
		} catch let error1 as NSError {
			error = error1
			inputDevice = nil
			print(error)
		}  
		
		//Configure the device
		configureCaptureDevice(self.captureDevice!)
		
		if let inp = inputDevice {
			
			session.addInput(inp)
		
			//Add layers
			self.addPreviewLayer()
			self.addFocusBorder()
			
			//Configure the output
			let outputSettings: NSDictionary = [AVVideoCodecKey: AVVideoCodecJPEG]
			output.outputSettings = outputSettings as! [NSObject: AnyObject]
			session.addOutput(output)
			
			session.startRunning()
			
		} else {
		
			/*If the capture device cannot be used for input, an error is printed out. 
			You may want to inform the user, too, through the use of an AlertController object.*/
			print(error)
		}
	}
	
	//Adds the preview layer which displays the video stream 
    private func addPreviewLayer() {
		
        self.previewLayer = AVCaptureVideoPreviewLayer(session: session)
        self.previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill
        self.previewLayer.bounds = self.view.bounds
        self.previewLayer.position = CGPointMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds))
        self.view.layer.addSublayer(previewLayer)
    }
	
	private func addFocusBorder() {
	
		self.focusBorder = BorderOverlay(frame: self.view.bounds)
        self.focusBorder.backgroundColor = UIColor.clearColor()
        self.focusBorder.hidden = true;
        self.view.addSubview(self.focusBorder)
	}
	
	
	private func rotateSubviewsToVertical() {
		
		self.previewLayer.position = CGPointMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds))
		self.previewLayer.bounds = self.view.bounds
		self.previewLayer.connection?.videoOrientation = AVCaptureVideoOrientation.Portrait
		
	}
	
	private func rotateSubviewsToHorizontalRight() {
		
		self.previewLayer.position = CGPointMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds))
		self.previewLayer.bounds = self.view.bounds
		self.previewLayer.connection?.videoOrientation = AVCaptureVideoOrientation.LandscapeRight
		
	}

	private func rotateSubviewsToHorizontalLeft() {
	
		self.previewLayer.position = CGPointMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds))
		self.previewLayer.bounds = self.view.bounds
		self.previewLayer.connection?.videoOrientation = AVCaptureVideoOrientation.LandscapeLeft
		
	}
	
	private func rotateSubviewsToUpsideDown() {
		
		self.previewLayer.position = CGPointMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds))
		self.previewLayer.bounds = self.view.bounds
		self.previewLayer.connection?.videoOrientation = AVCaptureVideoOrientation.PortraitUpsideDown
	}
	
	private func runStillImageCaptureAnimation(previewLayer pl: AVCaptureVideoPreviewLayer)
	{
		self.view.alpha = 0.5
		UIView.animateWithDuration(10.15, animations: { () -> Void in
			self.view.alpha = 1.0
		})
	}
	
	private func checkDeviceAuthorizationStatus(device: AVCaptureDevice) {
		
		AVCaptureDevice.requestAccessForMediaType(AVMediaTypeVideo, completionHandler: { (granted: Bool) -> Void in
		
			if granted {
			
				self.prepareSession()
				
			} else {
			
				self.cameraIsNotAvailable = true
			}
		})
	}
	
	private func stop() {
		
        self.session.stopRunning()
        self.previewLayer.removeFromSuperlayer()
    }
	
	private func drawFocusRect(touchLocation: CGPoint) {
	
		//Draw a border around the focused area; start a timer which will hide the border once it fires
		let focusFrameRect = CGRectMake(touchLocation.x-50.0, touchLocation.y-50.0, 100.0, 100.0)
		let pointTL = CGPointMake(focusFrameRect.origin.x, focusFrameRect.origin.y)
		let pointTR = CGPointMake(focusFrameRect.origin.x+100.0, focusFrameRect.origin.y)
		let pointBR = CGPointMake(focusFrameRect.origin.x+100.0, focusFrameRect.origin.y+100.0)
		let pointBL = CGPointMake(focusFrameRect.origin.x, focusFrameRect.origin.y+100.0)
		let focusFrameCorners = [pointTL, pointTR, pointBR, pointBL, pointTL, pointTR]
		
		let color: BorderOverlayColor = .White
		//self.focusBorder.lineWidth = 1.5
		self.focusBorder.drawBorder(focusFrameCorners, color: color)
		self.focusBorder.hidden = false
		
		startBorderTimer()
	}

	
	private func startBorderTimer() {
		
		if borderTimer?.valid == true {
			borderTimer?.invalidate()
			startBorderTimer()
		} else {
			borderTimer = NSTimer.scheduledTimerWithTimeInterval(2.0, target: self, selector: "borderTimerFireMethod:", userInfo: nil, repeats: false)
			borderTimer!.tolerance = 0.1
			//A non-repeating timer fires once and then invalidates itself automatically, thereby preventing the timer from firing again (Apple Developer Documentation)
		}
    }
	
	//Removes the border and hides the capture button:
	@objc func borderTimerFireMethod(timer: NSTimer) {
		/* Remove the identified border & invalidate the scan's result*/
        self.focusBorder.hidden = true
	}
	

	
	/*Focuses to a point of interest specified by a touch location.
	The location needs to be converted to a point between (0,0) = top left and (1,1) = bottom right in portrait mode, with the home button being on the right */
	private func focusWithMode(device: AVCaptureDevice, focusMode: AVCaptureFocusMode, exposureMode: AVCaptureExposureMode, monitorSubjectAreaChange: Bool, focusPoint point: CGPoint, focusRectCenter: CGPoint?) {
			
		do {
			try device.lockForConfiguration()
		} catch _ {
		}
		if device.focusPointOfInterestSupported && device.isFocusModeSupported(focusMode) {

			device.focusPointOfInterest = point
			device.focusMode = focusMode
		}
		
		if device.exposurePointOfInterestSupported && device.isExposureModeSupported(exposureMode) {
		
			device.exposurePointOfInterest = point
			device.exposureMode = exposureMode
		}
		
		device.subjectAreaChangeMonitoringEnabled = monitorSubjectAreaChange
		device.unlockForConfiguration()
		
		if let rectCenter = focusRectCenter {
			drawFocusRect(rectCenter)
		}
	}
	
	private func configureCaptureDevice(device: AVCaptureDevice) {
		
		do {
			try device.lockForConfiguration()
		} catch _ {
		}
		
		if configureFlash(device, mode: self.currentFlashMode, lockAndUnlockForConfig: false) == nil {
			
			let alternateMode = AVCaptureFlashMode.Off
			if configureFlash(device, mode: alternateMode, lockAndUnlockForConfig: false) != nil {
				
				self.currentFlashMode = alternateMode
			}
		}
		
		if configureTorch(device, mode: self.currentTorchMode, lockAndUnlockForConfig: false) == nil {
		
			let alternateMode = AVCaptureTorchMode.On
			if configureTorch(device, mode: alternateMode, lockAndUnlockForConfig: false) != nil {

				self.currentTorchMode = alternateMode
			}
		}
		
		device.unlockForConfiguration()
	}
 
	//Device configuration methods: by default, set both parameters to true, unless you call them in sequence; returns the new flash mode if successfully set to mode
    private func configureFlash(device: AVCaptureDevice, mode: AVCaptureFlashMode, lockAndUnlockForConfig: Bool) -> AVCaptureFlashMode? {
	
		var returnOK = false
		
		if device.hasFlash {
			if device.isFlashModeSupported(mode) {
				if device.flashAvailable {
			
					if lockAndUnlockForConfig {
						do {
							try device.lockForConfiguration()
						} catch _ {
						}
					}
					
					device.flashMode = mode
					returnOK = true
					
					if lockAndUnlockForConfig {
						device.unlockForConfiguration()
					}
					
				} else {
				
					if self.parentVC != nil {
		
						let VC = self.parentVC as! UIViewController

						let alert = AlertController(
							buttons: .OK, 
							title: "Error", 
							messageText: "No flash available. Please allow for it to cool down and try again.", 
							btn1Action: nil, 
							btn2Action: nil)
										
						//The built target is iOS 8 => alert may be force-unwrapped without risk of the app crashing
						alert!.present(parent: VC)
					}
				}
			} else {
			
				print("Selected flash mode \(mode) not supported")
			}
		}
		
		if returnOK {
			return mode
		} else {
			return nil
		}
    }
	
	//Device configuration methods: by default, set both parameters to true, unless you call them in sequence; returns the new torch mode if successfully set to mode
	private func configureTorch(device: AVCaptureDevice, mode: AVCaptureTorchMode, lockAndUnlockForConfig: Bool) -> AVCaptureTorchMode? {
		
		var returnOK = false
			
		if deviceHasTorch()! {
			if device.isTorchModeSupported(mode) {
				if device.torchAvailable {
			
					if lockAndUnlockForConfig {
						do {
							try device.lockForConfiguration()
						} catch _ {
						}
					}
					
					device.torchMode = mode
					returnOK = true
			
					if lockAndUnlockForConfig {
						device.unlockForConfiguration()
					}
					
				} else {
					
					let VC = self.parentViewController!
					
					let alert = AlertController(
						buttons: .OK, 
						title: "Error", 
						messageText: "Torch not available. Please allow for it to cool down and try again.", 
						btn1Action: nil, 
						btn2Action: nil)
										
						//The built target is iOS 8 => alert may be force-unwrapped without risk of the app crashing
						alert!.present(parent: VC)
				}
			}
		}
		
		if returnOK {
			return mode
		} else {
			return nil
		}
	}
	
	internal func deviceHasFlash() -> Bool? {
	
		if let device = self.captureDevice {
		
			return device.hasFlash
			
		} else {
		
			return nil
		}
	}
	
	internal func deviceHasTorch() -> Bool? {
	
		if let device = self.captureDevice {
		
			return device.hasTorch
			
		} else {
		
			return nil
		}
	}

	internal func capture() {
		
		var videoConnection: AVCaptureConnection?
		
		//Look for the connection whose input port is collecting video
		for connection in output.connections {
			
			if let inputPorts = connection.inputPorts {
			
				for port in inputPorts {
			
					if let inputPort = port as? AVCaptureInputPort {
				
						if inputPort.mediaType == AVMediaTypeVideo {
						
							videoConnection = connection as? AVCaptureConnection
							break
						}
					}
				}
			}
			
			if videoConnection != nil { break }
		}
		
		if videoConnection != nil {
		
			var image: UIImage?
				
			// Update the orientation on the still image output video connection before capturing.
			self.output.connectionWithMediaType(AVMediaTypeVideo).videoOrientation = self.previewLayer.connection.videoOrientation
		
			//Capture the image
			output.captureStillImageAsynchronouslyFromConnection(videoConnection, completionHandler: { (imageBuffer, error) -> Void in
				
				if error == nil {
				
					if let _ = CMGetAttachment(imageBuffer, kCGImagePropertyExifDictionary, nil) {
						//Store the attachment
						let imageData: NSData = AVCaptureStillImageOutput.jpegStillImageNSDataRepresentation(imageBuffer)
						image = UIImage(data: imageData)
						
						self.runStillImageCaptureAnimation(previewLayer: self.previewLayer)
					} 
					
				} else {
				
					print("\(error)")
				}
			})
			
			//Exit
			self.stop()
            
			//Dismiss this view controller and hand over the picture
			(self.parentViewController as! CameraViewDelegate).dismissAndHandOver(picture: image)
		} else {
		
			print("Error  videoConnection is nil")
		}
	}
    
    internal func cancel() {
        
		self.stop()
            
		//Dismiss this view controller
		(self.parentViewController as! CameraViewDelegate).dismissAndHandOver(picture: nil)
    }
	
	internal func flashMode() -> AVCaptureFlashMode {
	
		return self.currentFlashMode
	}
		
	internal func setFlashMode(newMode: AVCaptureFlashMode) -> AVCaptureFlashMode? {
	
		if let device = self.captureDevice {

			if configureFlash(device, mode: newMode, lockAndUnlockForConfig: true) != nil {
			
				self.currentFlashMode = newMode
				return self.currentFlashMode
			
			} else {
		
				return nil
			}
			
		} else {
		
			return nil
		}
	}
	
	internal func torchMode() -> AVCaptureTorchMode {
	
		return self.currentTorchMode
	}
	
	internal func setTorchMode(newMode: AVCaptureTorchMode) -> AVCaptureTorchMode? {
	
		if let device = self.captureDevice {
		
			if configureTorch(device, mode: newMode, lockAndUnlockForConfig: true) != nil {
				
				self.currentTorchMode = newMode
				return self.currentTorchMode
				
			} else {
			
				return nil
			}
			
		} else {
		
			return nil
		}
	}
	
	internal func setInfoText(text: String) -> Void {
	
		self.informationLabel.text = text
	}
}

