

import Foundation
import UIKit
import AVFoundation


class SamplePanel: UIView {

	struct ConstraintConstantValues {
		
		var lead: CGFloat
		var top: CGFloat
		var width: CGFloat
		var height: CGFloat
		
		init (_ lead: CGFloat, _ top: CGFloat, _ width: CGFloat, _ height: CGFloat) {
		
			self.lead = lead
			self.top = top
			self.width = width
			self.height = height
		}
	}
	
	var portraitConstants = ConstraintConstantValues(4.0, 25.0, 180.0, 108.0)
	var landscapeConstants = ConstraintConstantValues(4.0, 25.0, 108.0, 180.0)
	
	
}

/*The code reader support view controller communicates with the code reader view controller via a delegate (and through another delegate they communicate vice-versa). */
class CameraSupportViewController: UIViewController {
		
	var informationText: String = "Please take a photo analoguous to the sample picture" //default value
	var sampleImage: UIImage?
	var sampleLabelText: String? = "Sample"
	
	var vcdp: ViewControllerDataPropagation!
	
	var currentRequestID: Int? //This camera session's ID; if available, it will be returned together with the picture as to provide the receiver with a means of identification
	var parentVC: CameraPictureReceiver?
	
	private var cameraView: CameraSupportViewDelegate?
	private let segueToCamera = "CameraSupportEmbedsCamera"
	
	@IBOutlet weak var samplePanel: SamplePanel!
	@IBOutlet weak var container: UIView!
	@IBOutlet weak var cancelButton: UIBarButtonItem!
	@IBOutlet weak var captureButton: UIBarButtonItem!
	@IBOutlet weak var torchButton: UIBarButtonItem!
	@IBOutlet weak var flashButton: UIBarButtonItem!
	@IBOutlet weak var sampleLabel: UILabel!
	@IBOutlet weak var sampleImageView: UIImageView!
	@IBOutlet weak var samplePanelWidth: NSLayoutConstraint!
	@IBOutlet weak var samplePanelHeight: NSLayoutConstraint!
	@IBOutlet weak var samplePanelLeadingAlignment: NSLayoutConstraint!
	@IBOutlet weak var samplePanelTopSpace: NSLayoutConstraint!
	
	override func viewDidLoad() {
        
        super.viewDidLoad()
		
		self.cameraView = (self.childViewControllers[0] as! CameraSupportViewDelegate)
		self.cameraView!.setInfoText(self.informationText)
	}
	
	override func viewWillAppear(animated: Bool) {
	
		super.viewWillAppear(animated)
		
		if self.sampleImage == nil {
			self.samplePanel.hidden = true
		} else {
			self.samplePanel.hidden = false
		}
		
		setFlashButtonIcon()
		setTorchButtonIcon()
	}
	
	
	override func viewDidAppear(animated: Bool) {

		super.viewDidAppear(animated)
		resizeSamplePanel() /*Resize the panel so as to leave leave no unintended, thick border lines around the aspect-fitted image
			& to accommodate the picture's orientation. */
	}
	
    override func didReceiveMemoryWarning() {
		
		super.didReceiveMemoryWarning()
    }
	
	override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
		
        if segue.identifier == self.segueToCamera {
            
            let nextVC = segue.destinationViewController as! CameraViewController
			nextVC.parentVC = self
		}
    }
	
	@IBAction func cancelButtonHit(sender: AnyObject) {
	
		self.cameraView!.cancel()
	}
	
	@IBAction func captureButtonHit(sender: AnyObject) {
		
		self.cameraView!.capture()
	}
	
	@IBAction func flashButtonHit(sender: AnyObject) {

		let flashMode = self.cameraView!.flashMode()

		switch flashMode {
			
			case .Auto: self.cameraView!.setFlashMode(.On);
			case .On: self.cameraView!.setFlashMode(.Off); 
			case .Off: fallthrough
			default: self.cameraView!.setFlashMode(.Auto); 

		}
		setFlashButtonIcon()
		setTorchButtonIcon()
	}
	
	@IBAction func torchButtonHit(sender: AnyObject) {
	
		let torchMode = self.cameraView!.torchMode()

		switch torchMode {
			
			case .On: self.cameraView!.setTorchMode(.Off); 
			case .Off: fallthrough
			default: self.cameraView!.setTorchMode(.On);
		}
		setTorchButtonIcon()
		setFlashButtonIcon()
	}
	
	private func setFlashButtonIcon() {
	
		if let flashMode = self.cameraView?.flashMode() {
		
			if self.cameraView?.deviceHasFlash() == true {
			
				self.flashButton.enabled = true
				switch flashMode {
					
					case .Auto: self.flashButton.image = UIImage(named: "flash-auto")
					case .On: self.flashButton.image = UIImage(named: "flash-on")
					case .Off: fallthrough
					default: self.flashButton.image = UIImage(named: "flash-off")
				}
			} else {
			
				self.flashButton.image = UIImage(named: "flash-off")
				self.flashButton.enabled = false
			}
		}
	}
	
	private func setTorchButtonIcon() {
	
		if let torchMode = self.cameraView?.torchMode() {
		
			if self.cameraView?.deviceHasTorch() == true {
			
				self.torchButton.enabled = true
				switch torchMode {
					
					case .On: self.torchButton.image = UIImage(named: "torch-on")
					case .Off: fallthrough
					default: self.torchButton.image = UIImage(named: "torch-off")
				}
			} else {
			
				self.torchButton.image = UIImage(named: "torch-off")
				self.torchButton.enabled = false
			}
		}
	}
	
	//Resizes the sample image panel in order to present the sample image in the correct orientation
	private func resizeSamplePanel() {
		
		self.sampleLabel.text = self.sampleLabelText

		if let image = self.sampleImage {
		
			var sizedImage: UIImage
			var newX, newY, newWidth, newHeight: CGFloat
			let size = image.size
			
			if size.width > size.height { //Landscape orientation
				
				sizedImage = Utilities.resizeImage(image, newHeight: samplePanel.landscapeConstants.height)
				let maxSizeFactor = sizedImage.size.height * 2.0 //The image panel's width is limited to two times the height
				
				if sizedImage.size.width < maxSizeFactor {
				
					newX = samplePanel.landscapeConstants.lead
					newY = samplePanel.landscapeConstants.top
					newWidth = sizedImage.size.width
					newHeight = sizedImage.size.height
					
				} else {
					//If the image is too wide, the standard dimensions will be taken
					newX = samplePanel.landscapeConstants.lead
					newY = samplePanel.landscapeConstants.top
					newWidth = samplePanel.landscapeConstants.width
					newHeight = samplePanel.landscapeConstants.height
				}
				
			} else { //Portrait orientation
			
				sizedImage = Utilities.resizeImage(image, newHeight: samplePanel.portraitConstants.width)
				let maxSizeFactor = sizedImage.size.width * 2.0 //The image panel's height is limited to two times the width
				
				if sizedImage.size.height < maxSizeFactor {
				
					newX = samplePanel.portraitConstants.lead
					newY = samplePanel.portraitConstants.top
					newWidth = sizedImage.size.width
					newHeight = sizedImage.size.height
					
				} else {
					//If the image is too wide, the standard dimensions will be taken
					newX = samplePanel.portraitConstants.lead
					newY = samplePanel.portraitConstants.top
					newWidth = samplePanel.portraitConstants.width
					newHeight = samplePanel.portraitConstants.height
				}
			}
			
			//Have the panel's constraints adapt to the resized image's dimensions
			self.samplePanelLeadingAlignment.constant = newX
			self.samplePanelTopSpace.constant = newY
			self.samplePanelHeight.constant = newHeight
			self.samplePanelWidth.constant = newWidth
			self.samplePanel.setNeedsLayout()
			self.samplePanel.setNeedsUpdateConstraints()

			//Animate the change & replace the image by the resized image
			UIView.animateWithDuration(0.8, animations: { () -> Void in
				
				self.samplePanel.updateConstraintsIfNeeded()
				self.samplePanel.layoutIfNeeded()
				
			}, completion: { (completed) -> Void in
				
				if completed {
					
					self.sampleImageView.image = sizedImage
					self.sampleLabel.text = self.sampleLabelText
					self.sampleLabel.hidden = false
					
				} else {
				
					//%ERROR
				}
			})
		}
	}
	
	internal func setReturnInformation(parentVC vc: CameraPictureReceiver, requestID: Int? = nil) {
		
		self.parentVC = vc
		self.currentRequestID = requestID
	}

	internal func setUserInformation(sampleImage si: UIImage?, sampleLabelText sat: String?, infoText t: String? = nil) {
		
		if let image = si {
			self.sampleImage = image
		}
		self.sampleLabelText = sat
		if let text = t {
			self.informationText = text
		}
	}	
	
	
}


extension CameraSupportViewController: CameraViewDelegate {
	
	internal func dismissAndHandOver(picture picture: UIImage?) {
	
		self.dismissViewControllerAnimated(true) { () -> Void in

			if let pic = picture {
				
				self.parentVC?.newPictureAvailable(picture: pic)
				
			} else {
			
				//%ERROR LOG
			}
		}
	}
	
	internal func application() -> UIApplication {
	
		return self.vcdp.application
	}
}