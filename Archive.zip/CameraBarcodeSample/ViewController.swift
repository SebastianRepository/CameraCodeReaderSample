

import UIKit

class ViewController: UIViewController {

	var vcdp: ViewControllerDataPropagation!
	
	//The segue identifiers as declared in the storyboard
	let segueToCodeReaderSupportVC = "ViewControllerToCodeReaderSupportVC"
	let segueToCameraSupportVC = "ViewControllerToCameraSupportVC"
	
	override func viewDidLoad() {
		super.viewDidLoad()
		// Do any additional setup after loading the view, typically from a nib.
	}

	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
		// Dispose of any resources that can be recreated.
	}

	override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {

		//Propagate vcdp to the subsequent VCs

		if segue.identifier == segueToCodeReaderSupportVC {
			
			let nextVC = segue.destinationViewController as! CodeReaderSupportViewController
			nextVC.vcdp = self.vcdp 
			
			
		} else if segue.identifier == segueToCameraSupportVC {
			
			let nextVC = segue.destinationViewController as! CameraSupportViewController
			nextVC.vcdp = self.vcdp
			nextVC.sampleImage = UIImage(named: "sample_sample")
		}
	}
}

extension ViewController: CameraPictureReceiver {

	func newPictureAvailable(picture picture: UIImage) {
		
		
	}
}

