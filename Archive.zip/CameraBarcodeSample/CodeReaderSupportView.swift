
import Foundation
import UIKit

/*The CodeReaderSupportVC embeds a dedicated camera VC (CodeReaderVC).
CodeReaderSupportVC provides a user interface to the actual camera.
The user interface comprises a toolbar underneath the camera view, with two buttons:
Cancel and Capture.
The Cancel button is always enabled.
By default, the Capture button is also enabled.
However, if you assign a string value to :requiredDecodedText, the Capture button will only be enabled if the camera decodes a QR code with that string.

CodeReaderSupportVC and CodeReaderVC communicate according to the protocols.
Important: When preparing a segue to an instance of this VC, call :setReturnVC and :setCodeReaderTexts ! */
class CodeReaderSupportViewController: UIViewController {
	
	
	//Refer to CodeReaderViewController for more info on the following two parameters:
	private var informationText: String = "Please place the camera over the QR code" //Default
	private var requiredDecodedText: String?
	
	var vcdp: ViewControllerDataPropagation!
		
	@IBOutlet weak var container: UIView!
	@IBOutlet weak var cancelButton: UIBarButtonItem!
	@IBOutlet weak var captureButton: UIBarButtonItem!
	
	override func viewDidLoad() {
        
        super.viewDidLoad()
		
		self.requiredDecodedText = ""
		(self.childViewControllers[0] as! CodeReaderSupportViewDelegate).setCodeReaderTexts(requiredDecodedText: self.requiredDecodedText, informationText: self.informationText)
	}
	
	override func viewWillAppear(animated: Bool) {
	
		super.viewWillAppear(animated)
	}
	
	
	override func viewDidAppear(animated: Bool) {

		super.viewDidAppear(animated)
}
	
    override func didReceiveMemoryWarning() {
		
    }
	
	@IBAction func cancelButtonHit(sender: AnyObject) {
	
		(self.childViewControllers[0] as! CodeReaderSupportViewDelegate).cancelButtonHit()
	}
	
	@IBAction func captureButtonHit(sender: AnyObject) {
		
		(self.childViewControllers[0] as! CodeReaderSupportViewDelegate).captureButtonHit()
	}
	
	
	
	//Methods that must be called by the previous view controller prior to the segue:
	internal func setCodeReaderTexts(requiredDecodedText rt: String?, informationText it: String) {
		//For more info on the parameters see CodeReaderViewController
		
		self.requiredDecodedText = rt
		self.informationText = it
	}
	
	
	
}

extension CodeReaderSupportViewController: CodeReaderViewDelegate {
//Protocol methods that will be called by CodeReaderViewController:
	
	internal func dismissAndHandOver(decodedText decodedText: String?) {
	
		self.dismissViewControllerAnimated(true) { () -> Void in

			if decodedText != nil {
				
								
			} else {
				//%ERROR WARNING
			}
		}
	}
	
	internal func enableCaptureButton() {

		self.captureButton.enabled = true
	}

	internal func disableCaptureButton() {
	
		self.captureButton.enabled = false
	}
	
	internal func application() -> UIApplication {
	
		return self.vcdp.application
	}
}