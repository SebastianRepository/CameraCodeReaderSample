

import UIKit

//This enumeration defines the colors used by the discovered barcode view
enum BorderOverlayColor: Int {

	case Red = 0	//Use red whenever a specific code is searched for but another one is framed
	case Green = 1  //Use green whenever the specific code searched for is framed
	case Yellow = 2 //Use yellow in all cases where no specific code is searched for
	case White = 3	//Additional option that may be used by other applications than barcode-reading, for example by CameraViewController
}

/*A BorderOverlay object to draw a border around an area identified by a an array of points.*/
class BorderOverlay: UIView {
    
    private var borderLayer : CAShapeLayer?
    private var corners : [CGPoint]?
	internal var lineWidth: CGFloat = 3.0
	
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.setView(lineWidth: self.lineWidth)
    }
	
	required init?(coder aDecoder: NSCoder) {
	
		super.init(coder: aDecoder)
	}
    
    func drawBorder(points : [CGPoint], color: BorderOverlayColor) {
        
        self.corners = points
        let path = UIBezierPath()
        
        path.moveToPoint(points.first!)
        
        for (var i = 0; i<points.count; i++) {
            path.addLineToPoint(points[i])
        }
        
        path.addLineToPoint(points.first!)
		setStrokeColor(color)
        borderLayer?.lineWidth = lineWidth
        borderLayer?.path = path.CGPath
    }
	
	private func setView(lineWidth lineWidth: CGFloat) {
        
        borderLayer = CAShapeLayer()
		setStrokeColor(.Yellow)
        borderLayer?.fillColor = UIColor.clearColor().CGColor
        self.layer.addSublayer(borderLayer!)
    }
	
	private func setStrokeColor(color: BorderOverlayColor) {
	
		switch color {
			case .White: borderLayer?.strokeColor = UIColor.whiteColor().CGColor
			case .Red:  borderLayer?.strokeColor = UIColor.redColor().CGColor
			case .Green:  borderLayer?.strokeColor = UIColor.greenColor().CGColor
			case .Yellow:  fallthrough
			default: borderLayer?.strokeColor = UIColor.yellowColor().CGColor
		}
	}
}
