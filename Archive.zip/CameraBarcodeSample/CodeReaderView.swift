

import Foundation
import UIKit
import AVFoundation

//The code reader view controller communicates with the code reader support view controller via a delegate (and through another delegate they communicate vice-versa)
class CodeReaderViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate, CodeReaderSupportViewDelegate {
		
    private let session = AVCaptureSession()
    private var previewLayer = AVCaptureVideoPreviewLayer()
    private var identifiedBorder: BorderOverlay
    private var timer: NSTimer?
    private var decodedText: String?
	
    private var requiredDecodedText: String? //must be nil or "" if the Capture button shall be enabled at all times
    private var userConfirmedDecodedText: String?  //the text decoded and user-confirmed (by hitting the Capture button)
    
	@IBOutlet weak var informationLabel: UILabel!
	
    required init?(coder: NSCoder)
    {        
        let rect = CGRect()
        self.identifiedBorder = BorderOverlay(frame: rect)
		
        super.init(coder: coder)
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: NSBundle?) {
       
        let rect = CGRect()
        self.identifiedBorder = BorderOverlay(frame: rect)
		        
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
	
	          
    override func viewDidLoad() {
		
        super.viewDidLoad()
        
        let captureDevice = AVCaptureDevice.defaultDeviceWithMediaType(AVMediaTypeVideo)
        
        var error : NSError?
        let inputDevice: AVCaptureDeviceInput!
        do {
            inputDevice = try AVCaptureDeviceInput(device: captureDevice)
        } catch let error1 as NSError {
            error = error1
            inputDevice = nil
        }
        
        if let inp = inputDevice {
            
            session.addInput(inp)
            
        } else {
            
            print(error)
        }
        
        self.addPreviewLayer()
        self.addDiscoveredBorder()
        
        /* Check for metadata */
        let output = AVCaptureMetadataOutput()
        session.addOutput(output)
        output.metadataObjectTypes = output.availableMetadataObjectTypes
        output.setMetadataObjectsDelegate(self, queue: dispatch_get_main_queue())
        session.startRunning()
    }
	
	override func viewWillAppear(animated: Bool) {
		
		self.setButtonStates()
	}
    
    override func didReceiveMemoryWarning() {
        
        self.stop()
    }
	
	override func viewWillLayoutSubviews() {
		
		let app = (self.parentViewController as! CodeReaderViewDelegate).application()
		switch app.statusBarOrientation {
			case UIInterfaceOrientation.LandscapeLeft: rotateSubviewsToHorizontalLeft()
			case UIInterfaceOrientation.LandscapeRight: rotateSubviewsToHorizontalRight()
			case UIInterfaceOrientation.Portrait: fallthrough
			case UIInterfaceOrientation.PortraitUpsideDown: fallthrough
			case UIInterfaceOrientation.Unknown: fallthrough
			default: rotateSubviewsToVertical()
		}
		
		self.startTimer()
	}
	
    private func addPreviewLayer() {
        
        previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill
        previewLayer.bounds = self.view.bounds
        previewLayer.position = CGPointMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds))
        self.view.layer.addSublayer(previewLayer)
    }
    
    private func addDiscoveredBorder() {
        
        identifiedBorder = BorderOverlay(frame: self.view.bounds)
        identifiedBorder.backgroundColor = UIColor.clearColor()
        identifiedBorder.hidden = true;
        self.view.addSubview(identifiedBorder)
    }
    
    private func stop() {
        
        self.session.stopRunning()
        
        self.identifiedBorder.removeFromSuperview()
        self.previewLayer.removeFromSuperlayer()
    }
    
    private func startTimer() {
		
		if timer?.valid == true {
			timer?.invalidate()
			startTimer()
		} else {
			timer = NSTimer.scheduledTimerWithTimeInterval(0.5, target: self, selector: "timerFireMethod:"/*""*/, userInfo: nil, repeats: false)
			timer!.tolerance = 0.1
			//A non-repeating timer fires once and then invalidates itself automatically, thereby preventing the timer from firing again (Apple Developer Documentation)
		}
    }
	
	
	//Removes the border and hides the capture button:
	@objc func timerFireMethod(timer: NSTimer) {
		/* Remove the identified border & invalidate the scan's result*/
        self.identifiedBorder.hidden = true
		self.decodedText = nil
        //DeactivateCaptureButton
        (self.parentViewController as! CodeReaderViewDelegate).disableCaptureButton()
	}
	
	private func rotateSubviewsToVertical() {
	
		self.previewLayer.position = CGPointMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds))
        self.previewLayer.bounds = self.view.bounds
		self.previewLayer.connection.videoOrientation = AVCaptureVideoOrientation.Portrait
	}
	
	private func rotateSubviewsToHorizontalRight() {
		
		self.previewLayer.position = CGPointMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds))
		self.previewLayer.bounds = self.view.bounds
		self.previewLayer.connection.videoOrientation = AVCaptureVideoOrientation.LandscapeRight
	}

	private func rotateSubviewsToHorizontalLeft() {
		
		self.previewLayer.position = CGPointMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds))
		self.previewLayer.bounds = self.view.bounds
		self.previewLayer.connection.videoOrientation = AVCaptureVideoOrientation.LandscapeLeft
	}
	
	private func translatePoints(points : [AnyObject], fromView : UIView, toView: UIView) -> [CGPoint] {
        
        var translatedPoints : [CGPoint] = []
        
        for point in points {
            
            let dict = point as! NSDictionary
            let x = CGFloat((dict.objectForKey("X") as! NSNumber).floatValue)
            let y = CGFloat((dict.objectForKey("Y") as! NSNumber).floatValue)
            let curr = CGPointMake(x, y)
            let currFinal = fromView.convertPoint(curr, toView: toView)
			
            translatedPoints.append(currFinal)
        }
        
        return translatedPoints
    }
	
	internal func captureOutput(captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [AnyObject]!, fromConnection connection: AVCaptureConnection!) {
        
        for data in metadataObjects {
            
            let metaData = data as! AVMetadataObject
            
            let transformed = previewLayer.transformedMetadataObjectForMetadataObject(metaData) as? AVMetadataMachineReadableCodeObject
            
            if let unwraped = transformed {
                
                identifiedBorder.frame = unwraped.bounds
                
                let identifiedCorners = translatePoints(unwraped.corners, fromView: self.view, toView: self.identifiedBorder)
				
				self.decodedText = transformed?.stringValue
				
				var color: BorderOverlayColor = .Yellow
				//If a specific decoded text is looked for, paint the frame's color in either green (for good) or red (for wrong code)
				if let _ = self.requiredDecodedText {
					if self.decodedText == self.requiredDecodedText {
						color = .Green
					} else {
						color = .Red
					}
				}
				
                identifiedBorder.drawBorder(identifiedCorners, color: color)
                self.identifiedBorder.hidden = false
                
                /* Activate this line to show the decoded text instead of the preset information text:*/
                //self.informationLabel.text = self.decodedText
   
				self.setButtonStates()
				
                self.startTimer()
            }
        }
    }
    
	
	private func setButtonStates() {
	
		//For reference, see comment for the requiredDecodedText property
		if let requiredText = self.requiredDecodedText {
				
			if requiredText != "" {

				if let myDecodedText = self.decodedText {
					
					if  myDecodedText == requiredText {
					
						(self.parentViewController as! CodeReaderViewDelegate).enableCaptureButton()
					
					} else {
			
						(self.parentViewController as! CodeReaderViewDelegate).disableCaptureButton()
					}
					
				} else {
			
					(self.parentViewController as! CodeReaderViewDelegate).disableCaptureButton()
				}
		
			} else {
		
				(self.parentViewController as! CodeReaderViewDelegate).enableCaptureButton()
			}
		
		} else {
		
			(self.parentViewController as! CodeReaderViewDelegate).enableCaptureButton()
		}
	}
	
	
	//Delegate protocol methods:
	
	internal func captureButtonHit() {
        
        if let dT = self.decodedText {

            self.userConfirmedDecodedText = dT

            self.stop()
            
            //Dismiss this view controller and hand over the confirmed, decoded text
			(self.parentViewController as! CodeReaderViewDelegate).dismissAndHandOver(decodedText: self.userConfirmedDecodedText)

        } else {
			//%ERROR HANDLING% log this
		}
    }
    
    internal func cancelButtonHit() {
        
        self.stop()
            
		//Dismiss this view controller and hand over information cancellation
		(self.parentViewController as! CodeReaderViewDelegate).dismissAndHandOver(decodedText: nil)
    }
	
	internal func setCodeReaderTexts(requiredDecodedText rt: String?, informationText it: String) {
	
		self.requiredDecodedText = rt
		self.informationLabel.text = it
	}
}



